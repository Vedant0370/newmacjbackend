const response = (data, message, error) => {
  return {
    data,
    message,
    error,
  };
};


module.exports = response;